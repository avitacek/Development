//
//  NSString+URLDecode.h
//  iRepEmulator
//
//  Created by Bergman, Adam on 8/12/13.
//  Copyright (c) 2013 Adam Bergman. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (URLDecode)

- (NSString *)stringByDecodingURLFormat;

@end
