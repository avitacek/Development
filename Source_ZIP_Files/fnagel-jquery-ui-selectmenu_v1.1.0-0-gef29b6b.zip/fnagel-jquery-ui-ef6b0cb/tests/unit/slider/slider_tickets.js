/*
 * slider_tickets.js
 */
(function($) {

module("slider: tickets");

})(jQuery);
