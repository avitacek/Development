/**
 * @author alteredq / http://alteredqualia.com/
 */

THREE.ColorUtils = {
	
	adjustHSV : function ( color, h, s, v ) {

		var hsv = THREE.ColorUtils.__hsv;
		
		THREE.ColorUtils.rgbToHsv( color, hsv );

		hsv.h = THREE.ColorUtils.clamp( hsv.h + h, 0, 1 );
		hsv.s = THREE.ColorUtils.clamp( hsv.s + s, 0, 1 );
		hsv.v = THREE.ColorUtils.clamp( hsv.v + v, 0, 1 );
		
		color.setHSV( hsv.h, hsv.s, hsv.v );

	},
	
	// based on MochiKit implementation by Bob Ippolito

	rgbToHsv : function ( color, hsv ) {

		var r = color.r;
		var g = color.g;
		var b = color.b;
		
		var max = Math.max( Math.max( r, g ), b );
		var min = Math.min( Math.min( r, g ), b );

		var hue;
		var saturation;
		var value = max;

		if ( min == max )	{

			hue = 0;
			saturation = 0;

		} else {

			var delta = ( max - min );
			saturation = delta / max;

			if ( r == max )	{

				hue = ( g - b ) / delta;

			} else if ( g == max ) {

				hue = 2 + ( ( b - r ) / delta );

			} else	{

				hue = 4 + ( ( r - g ) / delta );
			}

			hue /= 6;

			if ( hue < 0 ) {

				hue += 1;

			}
			
			if ( hue > 1 ) {

				hue -= 1;

			}

		}
		
		if ( hsv === undefined ) {
			
			hsv = { h: 0, s: 0, v: 0 };

		}
		
		hsv.h = hue;
		hsv.s = saturation;
		hsv.v = value;
		
		return hsv;

	},
	
	clamp: function ( x, a, b ) { 
		
		return x < a ? a : ( x > b ? b : x ); 

	}

};

THREE.ColorUtils.__hsv = { h: 0, s: 0, v: 0 };