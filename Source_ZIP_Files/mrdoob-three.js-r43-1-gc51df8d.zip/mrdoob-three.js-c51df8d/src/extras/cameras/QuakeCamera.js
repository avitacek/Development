/**
 * @author chriskillpack / http://chriskillpack.com/
 *
 * QuakeCamera has been renamed FirstPersonCamera. This property exists for backwards
 * compatibility only.
 */
THREE.QuakeCamera = THREE.FirstPersonCamera;
