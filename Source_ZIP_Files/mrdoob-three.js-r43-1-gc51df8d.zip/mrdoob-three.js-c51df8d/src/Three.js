/**
 * @author mr.doob / http://mrdoob.com/
 */

var THREE = THREE || {};

if ( ! window.Int32Array ) {

	window.Int32Array = Array;
	window.Float32Array = Array;

}
