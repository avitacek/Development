#!/bin/sh

python build.py --all --minified
