#!/bin/sh

python build.py --common --minified
