Autodesk FBX SDK Python bindings

http://usa.autodesk.com/adsk/servlet/pc/index?siteID=123112&id=6837478