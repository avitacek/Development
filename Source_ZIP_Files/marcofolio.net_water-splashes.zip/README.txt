                                __      _ _                   _   
                               / _|    | (_)                 | |  
 _ __ ___   __ _ _ __ ___ ___ | |_ ___ | |_  ___   _ __   ___| |_ 
| '_ ` _ \ / _` | '__/ __/ _ \|  _/ _ \| | |/ _ \ | '_ \ / _ \ __|
| | | | | | (_| | | | (_| (_) | || (_) | | | (_) || | | |  __/ |_ 
|_| |_| |_|\__,_|_|  \___\___/|_| \___/|_|_|\___(_)_| |_|\___|\__|
==================================================================
TEXTURE PACK - WATER SPLASHES
==================================================================
PHOTOGRAPHER:            Marco Kuiper
WEBSITE:                 http://www.marcofolio.net/
COUNTRY:                 The Netherlands
COPYRIGHT:               None, but a link to my site would be nice
==================================================================
   All photographs are taken with a Sony A200 on a bright
   day. None of them are edited in any way, exept some have
   non-texture parts removed.
==================================================================