My first jQuery plugin I've written with the help of the Yeoman jQuery plugin boilerplate generator. I feel that many jQuery plugins I find have too many options, too complex for the problem I am trying to solve and have a rather large footprint.

This simple plugin allows for smooth scrolling to an anchor on a page and fallbacks to the default behaivor with Javascript turned off. This is useful for single page portfolio sites or as a table of contents for long articles. There are only two options and the minified file is very lightweight.

Check out the [nicklauftw.com/a-smooth-scroll](demo)
