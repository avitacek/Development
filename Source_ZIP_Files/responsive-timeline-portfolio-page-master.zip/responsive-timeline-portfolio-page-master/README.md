#Building the Responsive Timeline Portfolio Page

During this tutorial we will be building the fantastic Timeline Portfolio as seen in an earlier tutorial by Tomas Laurinavicius. We will be using some responsive techniques as well as CSS3 animations, Sass and a little bit of jQuery.

ttps://webdesign.tutsplus.com/tutorials/building-the-responsive-timeline-portfolio-page--cms-19508
