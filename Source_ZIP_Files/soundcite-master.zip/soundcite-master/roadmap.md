# Roadmap

## Beta release: end of April

* Redesign of embed generator and UX
* Custom theming of SoundCite player UI
* Homepage consistent with other Knight Lab projects

## Future (1.0)

* Other audio sources (YouTube?)
* Draggable waveform for clip creation
